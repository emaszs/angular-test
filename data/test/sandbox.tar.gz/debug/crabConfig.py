from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'tutorial_May2015_MC_analysis'
config.General.instance = 'mmascher-mon.cern.ch'
config.section_('JobType')
config.JobType.psetName = 'pset_tutorial_analysis.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDataset = '/GenericTTbar/HC-CMSSW_5_3_1_START53_V5-v1/GEN-SIM-RECO'
config.Data.publication = True
config.Data.unitsPerJob = 10
config.Data.publishDataName = 'CRAB3_tutorial_May2015_MC_analysis'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/erupeika/'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
